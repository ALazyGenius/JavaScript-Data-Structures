{
    class Node {
    constructor(val) {
        this.value = val;
        this.next = null;
        }
    }

    class SinglyLinkedList {
        constructor() {
            this.head = null;
            this.tail = null;
            this.length = 0;
        }

        push(val) {
            var newNode = new Node(val);
            if (!this.head) {
                this.head = newNode;
                this.tail = this.head;
            } else {
                this.tail.next = newNode;
                this.tail = newNode;
            }
            this.length += 1;
            return this;
        }

        get(index) {
            if (index < 0 || index >= this.length) {
                return null;
            }
            if (index === 0) {
                return this.head;
            } else {
                var count = 0;
                var nodeAtIndex = null;
                var current = this.head;
                while (count !== index) {
                    current = current.next;
                    nodeAtIndex = current;
                    count++;
                }
                return nodeAtIndex;
            }
        }

        unshift(val) {
            let node = new Node(val);
            if (!this.head) {
                this.head = node;
                this.tail = this.head;
            } else {
                node.next = this.head;
                this.head = node;
            }
            this.length++;
            return this;
        }

        insert(index, value) {
            if (index < 0 || index > this.length) {
                return undefined;
            } else {
                let nodeToBeInserted = new Node(value);
                if (index > 0 && index < this.length) {
                    let previousNode = this.get(index-1);
                    let currentNode =  this.get(index);
                    previousNode.next = nodeToBeInserted;
                    nodeToBeInserted.next = currentNode;
                    this.length++;
                } else if (index === this.length) {
                    this.push(value);
                } else {
                    this.unshift(value);
                }
                return this;
            }
        }
    }

    var list = new SinglyLinkedList();
    list.push("Hi");
    list.push("I");
    list.push("am");
    list.push("Akash");
    list.push("Mishra");
}