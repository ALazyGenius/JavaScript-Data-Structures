function sortArr(arr) {
    return arr.sort((a,b) => b-a);
}