function maxSubArraySum(arr, n) {
    let sum = -Infinity;
    if (arr.length === 0 || !n) {
        return null;
    } else {
        //[1,2,3,4,5,6,7], 4
        for (let i = 0; i < arr.length - n + 1; i++) { //[1,2,3,4]
            let sumCheck = 0;
            for (let j = 0; j < n; j++) { //[1,2,3,4]
                sumCheck += arr[i+j];
            }
            if (sumCheck > sum) {
                sum = sumCheck;
            }
        }
        return sum;
    }
} 