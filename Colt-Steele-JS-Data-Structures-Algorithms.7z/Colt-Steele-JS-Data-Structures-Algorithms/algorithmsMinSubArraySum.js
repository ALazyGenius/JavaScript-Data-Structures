function minSubarraySeq(arr, sum, p1 = 0, p2 = 1) {
    if (arr.length === 0 || !sum || isNaN(sum)) {
        return undefined;
    }
    let windowDiff = p1+p2;
    let total  = 0;
    while (p1 < arr.length -1 && p2 < arr.length) {
        const splicedArr = arr.slice(p1, p2+1);
        total = splicedArr.reduce((x, total = 0) => x + total);
        if (total === sum) {
            return `MIN SUB ARRAY: ${splicedArr}`;
        }
        p1++;
        p2++;
        if (p2 === arr.length) {
            windowDiff++;
            p1 = 0;
            p2 = windowDiff;
            if (p1 === 0 && p2 === arr.length) {
                return "Not Found";
            } else {
                minSubarraySeq(arr, sum, p1, p2);
            }
            
        }
    }
}

minSubarraySeq([1,2,3,9,6,7], 28);