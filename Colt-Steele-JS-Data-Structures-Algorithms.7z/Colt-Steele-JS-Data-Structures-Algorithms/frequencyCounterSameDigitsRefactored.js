function sameFrequency (num1, num2) {
    num1 = num1.toString();
    num2 = num2.toString();
    let freqNum1 = {};
    let freqNum2 = {};
    for (const digit of num1) {
        freqNum1[digit] = ++freqNum1[digit] || 1;
    }
    for (const digit of num2) {
        freqNum2[digit] = ++freqNum2[digit] || 1;
    }
    for (const key in freqNum1) {
        if (!(key in freqNum2)) {
            return false;
        }
        if (freqNum1[key] !== freqNum2[key]) {
            return false;
        }
    }
    return true;
}