function getDigit(num, value) {
    num = (Math.abs(num)).toString();
    return value < num.length ? parseInt(num.charAt(num.length - 1 - value),10) : 0;
}