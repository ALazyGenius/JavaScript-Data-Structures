function minSubArrayLen(arr, sum) {
    let total = 0;
    let start = 0;
    let end = 0;
    let minLength = Infinity;
    while (start < arr.length) {
        if (total < sum && end< arr.length) {
            total += arr[end];
            end++;
        } else if(total >= sum) {
            minLength = Math.min(minLength, end - start);
            total -= arr[start];
            start++;
        } else {
            break;
        }
    }
    return minLength === Infinity ? 0 : minLength;
}
