{
    class Graph {
        constructor() {
            this.adjacancyList = {};
        }
    }
}