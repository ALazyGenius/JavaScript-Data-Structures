{
    class HashTable {
        constructor(size=53) {
            this.keyMap = new Array(size);
        }

        _hash(key) {
            let total = 0;
            let prime = 31;
            for (let i = 0; i < Math.min(key.length, 100); i++) {
                let char = key[i];
                let value = char.toLowerCase().charCodeAt(0) - 96;
                total = (total * prime + value) % this.keyMap.length;
            }
            return total;
        }

        _set(key, value) {
            if (!key || !value) return undefined;
            let index = this._hash(key);
            if (!this.keyMap[index]) {
                this.keyMap[index] = [];
            }
            this.keyMap[index].push([key, value]);
            return this.keyMap;
        }

        _get(key) {
            if (!key) return undefined;
            let index = this._hash(key);
            if (this.keyMap[index]) {
                for (let i = 0; i < this.keyMap[index].length; i++) {
                    if (this.keyMap[index][i][0] === key) {
                        return this.keyMap[index][i];
                    }
                }
            }
            return undefined;
        }
    }

    var myHash = new HashTable(5);
    myHash._set("white", "#00000");
    myHash._set("whitee", "#00000");
    myHash._set("black", "#00001");
    myHash._set("blue", "#00002");
    myHash._set("red", "#00003");
}
