{
    class Node {
    constructor(val) {
        this.value = val;
        this.next = null;
        }
    }

    class SinglyLinkedList {
        constructor() {
            this.head = null;
            this.tail = null;
            this.length = 0;
        }

        push(val) {
            var newNode = new Node(val);
            if (!this.head) {
                this.head = newNode;
                this.tail = this.head;
            } else {
                this.tail.next = newNode;
                this.tail = newNode;
            }
            this.length += 1;
            return this;
        }

        get(index) {
            if (index < 0 || index >= this.length) {
                return null;
            }
            if (index === 0) {
                return this.head;
            } else {
                var count = 0;
                var nodeAtIndex = null;
                var current = this.head;
                while (count !== index) {
                    current = current.next;
                    nodeAtIndex = current;
                    count++;
                }
                return nodeAtIndex;
            }
        }

        shift() {
            if (!this.head) {
                return undefined;
            }
            var first = this.head;
            this.head = first.next;
            this.length--;
            return first;
        }

        pop() {
            if (!this.head) {
                return undefined;
            }
            var current = this.head;
            var newTail = current;
            while (current.next) {
                newTail = current;
                current = current.next;
            }
            this.tail = newTail;
            this.tail.next = null;
            this.length--;
            if (this.length === 0) {
                this.head = null;
                this.tail = null;
            }
            return current;
        }

        remove(index) {
            if (index < 0 || index > this.length) {
                return undefined;
            } else {
                let currentNode = null;
                if (index > 0 && index < this.length) {
                    let previousNode = this.get(index-1);
                    currentNode =  this.get(index);
                    previousNode.next = currentNode.next;
                    this.length--;
                } else if (index === this.length) {
                    currentNode = this.pop();
                } else {
                    currentNode = this.shift();
                }
                return currentNode;
            }
        }
    }

    var list = new SinglyLinkedList();
    list.push("Hi");
    list.push("I");
    list.push("am");
    list.push("Akash");
    list.push("Mishra");
}