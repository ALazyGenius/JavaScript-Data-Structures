{
    class Graph {
        constructor() {
            this.adjacancyList = {};
        }

        addVertex(vertex) {
            if(!this.adjacancyList[vertex]) this.adjacancyList[vertex] = [];
            return this.adjacancyList;
        }

        addEdge(vertex1, vertex2, weight) {
            if(!this.adjacancyList[vertex1]) this.addVertex(vertex1);
            this.adjacancyList[vertex1].push({node: vertex2, weight});
            return this.adjacancyList;
        }
    }

    var graph = new Graph();
    graph.addVertex("A");
    graph.addVertex("B");
    graph.addVertex("C");
    graph.addVertex("D");
    graph.addVertex("E");
    graph.addVertex("F");
    graph.addEdge("A", "B", 10);
    graph.addEdge("A", "C", 12);
    graph.addEdge("B", "D", 13);
    graph.addEdge("C", "E", 15);
    graph.addEdge("D", "E", 11);
    graph.addEdge("D", "F", 9);
    graph.addEdge("E", "F",8);
}