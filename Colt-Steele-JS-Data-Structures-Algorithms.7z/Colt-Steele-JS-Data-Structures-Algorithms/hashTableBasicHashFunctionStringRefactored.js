function hash(str, length) {
    if (!str || !length) return undefined;
    let total = 0;
    let prime = 31;
    for (let i = 0; i < Math.min(str.length, 100); i++) {
        let char = str[i].toLowerCase();
        let value = char.charCodeAt(0) - 96;
        total = (total * prime + value) % length;
    }
    return total;
}

//prime number in hash is useful in spreading out keys more uniformly
//reduces number of collisions