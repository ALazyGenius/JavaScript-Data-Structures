function capitalizeWords (str) {
    if (str.length === 0) return null;
    let capArr = [];
    function helper (helperArr) {
        if (helperArr.length === 0) {
            return "";
        }
        capArr.push(helperArr[0].toUpperCase())
        helper(helperArr.slice(1)); 
    }
    helper(str);
    return capArr;
}