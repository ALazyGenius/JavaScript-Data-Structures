function countUniqueValues(sortedArr) {
    var p1 = 0;
    var p2 = 1;
    if (sortedArr.length === 0) {
        return p1;
    } else if (sortedArr.length === 1) {
        return p1++;
    } else {
        while (p2 < sortedArr.length) {
            if (sortedArr[p1] !== sortedArr[p2]) {
            p1++;
            sortedArr.splice(p1, 0, sortedArr[p2]); 
        }
        p2++;
    }
    return p1+1;
    }
}