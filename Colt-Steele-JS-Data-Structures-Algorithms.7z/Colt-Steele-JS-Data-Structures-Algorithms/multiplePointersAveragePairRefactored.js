function averagePair(arr, avg) {
    let p1 = 0;
    let p2 = arr.length-1;
    while (p1 < p2) {
        const val = (arr[p1] + arr[p2])/2;
      if ( val=== avg) {
        return true;
      } else if (val < avg) {
            p1++;
      } else {
          p2--;
      }
    }
  return false;
}