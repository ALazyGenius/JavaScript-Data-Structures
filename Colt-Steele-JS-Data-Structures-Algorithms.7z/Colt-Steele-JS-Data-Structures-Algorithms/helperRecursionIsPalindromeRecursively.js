function isPalindrome (str) {
    let reverse = "";
    function helper(str) {
        if(str.length <= 0) {
            return "";
        }
        return str[str.length-1] + helper(str.slice(0,str.length-1));
    }
    reverse = helper(str);
    if (str === reverse) {
        return true;
    }
    return false;
}