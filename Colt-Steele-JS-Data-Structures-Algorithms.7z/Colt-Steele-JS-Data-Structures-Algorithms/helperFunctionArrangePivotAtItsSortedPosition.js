function arrangePivot (arr, start = 0, end = arr.length - 1) {
    let pivot = arr[start];
    let currentPivotIndex = start;
    for (let i = start+1; i <= end; i++) {
        if (pivot > arr[i]) {
            ++currentPivotIndex;
            swap(arr, currentPivotIndex, i);
        }
    }
    swap(arr, start, currentPivotIndex);
    console.log(arr);
    return currentPivotIndex;
}

function swap (arr, index1, index2) {
    let temp = arr[index1];
    arr[index1] = arr[index2];
    arr[index2] = temp;
    return arr;
}
