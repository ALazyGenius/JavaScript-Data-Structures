{
    class Node {
        constructor(val) {
            this.value = val;
            this.next = null;
            this.prev = null
        }
    }

    class DoublyLinkedList {
        constructor() {
                this.head = null;
                this.tail = null;
                this.length = 0;
        }

        push(val) {
            var newNode = new Node(val);
            if (!this.head) {
                this.head = newNode;
                this.tail = this.head;
            } else {
                this.tail.next = newNode;
                newNode.prev = this.tail;
                this.tail = newNode;
            }
            this.length += 1;
            return this;
        }

        get(index) {
            if (index < 0 || index >= this.length) {
                return null;
            }
            var current;
            if (index <= Math.floor(this.length/2)) {
                let count = 0;
                current = this.head;
                while (count < index) {
                    current = current.next;
                    count++;
                }
            } else {
                let count = this.length - 1;
                current = this.tail;
                while (count > index) {
                    current = current.prev;
                    count--;
                }
            }
            return current;
        }

        set(index, value) {
            let oldNode = this.get(index);
            if (oldNode) {
                oldNode.value = value;
                return this;
            }
            return false;
        }
    }

    var list = new DoublyLinkedList();
    list.push("Akash");
    list.push("Mishra");
    list.push("is");
    list.push("a");
    list.push("good");
    list.push("boy");
}