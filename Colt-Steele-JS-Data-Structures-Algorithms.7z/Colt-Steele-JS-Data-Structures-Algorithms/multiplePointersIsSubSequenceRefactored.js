function isSubSequence(str1, str2) {
    //hello, hello world
    if (str1.indexOf(str2) !== -1 || str2.indexOf(str1) !== -1) {
        return true;
    }
    let p1 = 0;
    while (str1.length != 0 || str2.length != 0) {
        if (str2.indexOf(str1[p1]) !== -1) {
            str2 = str2.replace(str1[p1],'');
            str1 = str1.replace(str1[p1],'');
          if (str1.length === 0 || str2.length === 0) {
            return true;
          }
        } else {
          p1++;
        }
    }
     return false;
}