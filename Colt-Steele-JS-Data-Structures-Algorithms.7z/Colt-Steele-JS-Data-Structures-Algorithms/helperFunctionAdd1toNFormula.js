function addtoN(n){
    return n * (n+1) / 2;
}

var timeBefore = performance.now();
console.log(addToN(100000000));
var timeAfter = performance.now();
console.log(`Time Elapsed: ${(timeAfter -timeBefore)/1000} seconds.`);
