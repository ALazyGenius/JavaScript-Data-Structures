function hash(str, arrLength) {
    if (!str || !arrLength) return undefined;
    let total = 0;
    for(let char of str) {
        total += char.toLowerCase().charCodeAt(0) - 96;
    }
    return total % arrLength;
}

//Hashes only strings
//Not constant time
//Could be a little random