function digitCount(num) {
    return Math.abs(num).toString().length ? Math.abs(num).toString().length : 0;
}