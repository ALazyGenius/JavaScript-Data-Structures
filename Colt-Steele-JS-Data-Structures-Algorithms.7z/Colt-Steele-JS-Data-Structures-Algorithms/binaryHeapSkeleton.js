{
    class BinaryHeap {
        constructor() {
            this.values = [];
        }
    }
}