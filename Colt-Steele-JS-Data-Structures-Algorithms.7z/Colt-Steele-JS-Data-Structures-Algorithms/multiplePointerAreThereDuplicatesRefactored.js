function areThereDuplicates(...args) {
  let arr = [...args];
  arr = arr.sort((x,y) => x - y);
  let start = 0;
  let next = 1;
  while(next < arr.length){
    if(arr[start] === arr[next]){
        return true;
    }
    start++;
    next++;
  }
  return false;
}