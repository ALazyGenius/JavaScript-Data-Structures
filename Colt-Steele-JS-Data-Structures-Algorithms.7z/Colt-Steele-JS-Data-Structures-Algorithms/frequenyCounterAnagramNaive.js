function validAnagram(str1, str2) {
    if (str1.length !== str2.length) {
        return false;
    }
    for (let char of str1) {
        char = char.toLowerCase();
        str2 = str2.toLowerCase();
        if (str2.indexOf(char) !== -1) {
            str2 = str2.slice(0, str2.indexOf(char)) + str2.slice(str2.indexOf(char) + 1, str2.length);
        } else {
            return false;
        }
    }
    return true;
}