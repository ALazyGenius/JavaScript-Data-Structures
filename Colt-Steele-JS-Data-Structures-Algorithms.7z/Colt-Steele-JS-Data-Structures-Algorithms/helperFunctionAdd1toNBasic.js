function addToN(n) {
    let total = 0;
    for(let i = 0; i <=n; i++) {
        total += i;
    }
    return total;
}

var timeBefore = performance.now();
console.log(addToN(100000000));
var timeAfter = performance.now();
console.log(`Time Elapsed: ${(timeAfter -timeBefore)/1000} seconds.`);