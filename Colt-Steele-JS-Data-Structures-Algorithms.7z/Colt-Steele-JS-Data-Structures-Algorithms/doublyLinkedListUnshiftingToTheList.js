{
    class Node {
        constructor(val) {
            this.value = val;
            this.next = null;
            this.prev = null
        }
    }

    class DoublyLinkedList {
        constructor() {
            this.head = null;
            this.tail = null;
            this.length = 0;
        }

        unshift(val) {
            var node = new Node(val);
            if (!this.head) {
                this.head = node;
                this.tail = this.head;
            } else {
                this.head.prev = node;
                node.next = this.head;
                this.head = node;
            }
            this.length++;
            return this;
        }
    }

    var list = new DoublyLinkedList();
    list.unshift("Akash");
    list.unshift("Mishra");
    list.unshift("is");
    list.unshift("a");
    list.unshift("good");
    list.unshift("boy");
}