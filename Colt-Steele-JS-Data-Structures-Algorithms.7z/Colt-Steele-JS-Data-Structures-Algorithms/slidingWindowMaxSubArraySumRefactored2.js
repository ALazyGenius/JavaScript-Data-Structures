function maxSubArraySum(arr, n) {
    if (arr && n && arr.length > n) {
        let maxSum = 0;
        let tempSum = 0;
        for (let i = 0; i < n; i++) {
            maxSum += arr[i];
        }
        tempSum = maxSum;
        //[1,2,3,4,5,6,7], 4
        for (let i = n; i < arr.length; i++) { //n=4, i=4
            tempSum = tempSum - arr[i-n] + arr[i];
            maxSum = Math.max(maxSum, tempSum);
        } 
        return maxSum;
    } else {
        return null;
    }
}