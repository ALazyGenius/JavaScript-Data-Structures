class Node{
    constructor(val) {
        this.value = val;
        this.next = null;
    }
}

var first = new Node("Hi");
first.next = new Node("Mr.");
first.next.next = new Node("Han");