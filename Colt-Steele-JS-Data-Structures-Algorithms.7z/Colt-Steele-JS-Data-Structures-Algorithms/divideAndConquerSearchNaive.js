function search (arr, n) {
    if (arr.length === 0 )
        return null;
    for (let i = 0; i < arr.length; i++) {
        if (n === arr[i]) {
            return i;
        }
    }
    return -1;
}
//Linear Search