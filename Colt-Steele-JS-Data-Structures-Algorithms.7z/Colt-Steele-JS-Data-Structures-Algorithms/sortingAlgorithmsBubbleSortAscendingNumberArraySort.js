function bubbleSort (arr) {
    var noSwaps;
    for (let i = arr.length - 1; i > 0; i--) {
        noSwaps = true;
        for (let j = 0; j <= i-1; j++) {
            if (arr[j] > arr[j+1]) {
                arr = swap(arr, j ,j+1);
                noSwaps = false;
            }
        }
        if (noSwaps) break;
    }
    return arr;
}

function swap (arr, i, j) {
    var temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
    return arr;
}