function sortStrLength (strArr) {
    return strArr.sort((a,b) => a.length - b.length);
}