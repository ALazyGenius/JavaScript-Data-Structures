function sortArr(arr) {
    return arr.sort((a,b) => a-b);
}