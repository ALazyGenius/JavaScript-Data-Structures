{
    class MaxBinaryHeap {
        constructor() {
            this.values = [];
        }
        insert(value) {
            if (!value) return undefined;
            this.values.push(value);
            this.bubbleUp();
        }
        bubbleUp() {
            let index = this.values.length - 1;
            const element = this.values[index];
            while(index > 0) {
                let parentIndex = Math.floor((index - 1)/2);
                let parent = this.values[parentIndex];
                if (element <= parent) break;
                this.swap(this.values, index, parentIndex);
                index = parentIndex;
            }
            return this.values;
        }
        swap(arr, el1, el2) {
            var temp = arr[el1];
            arr[el1] = arr[el2];
            arr[el2] = temp;
            return arr;
        }
    }

    var heap = new MaxBinaryHeap();
    heap.insert(41);
    heap.insert(39);
    heap.insert(33);
    heap.insert(18);
    heap.insert(27);
    heap.insert(12);
    heap.insert(55);
    heap.insert(75);
    heap.insert(60);
    heap.insert(199);
}


//                              199
//                  75                      41
//          55              60          12             33
//      18      39      27