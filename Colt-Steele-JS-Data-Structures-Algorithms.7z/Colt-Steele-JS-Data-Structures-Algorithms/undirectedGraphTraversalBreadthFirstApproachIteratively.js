{
    class Graph {
        constructor() {
            this.adjacancyList = {};
        }

        addVertex(vertex) {
            if(!this.adjacancyList[vertex]) this.adjacancyList[vertex] = [];
            return this.adjacancyList;
        }

        addEdge(vertex1, vertex2) {
            //For directed graph, push once. Pushing twice gives 2 directional flow
            if(!this.adjacancyList[vertex1]) this.addVertex(vertex1);
            this.adjacancyList[vertex1].push(vertex2);
            if(!this.adjacancyList[vertex2]) this.addVertex(vertex2);
            this.adjacancyList[vertex2].push(vertex1);
            return this.adjacancyList;
        }

        BFSIterative(vertex) {
            if(!this.adjacancyList[vertex].length) return "Base Case";
            var queue = [vertex];
            var result = [];
            var visited = {};
            let currentVertex;
            visited[vertex] = true;
            while (queue.length) {
                currentVertex = queue.shift();
                result.push(currentVertex);
                this.adjacancyList[currentVertex].forEach(element => {
                    if (!visited[element]) {
                        visited[element] = true;
                        queue.push(element);
                    }
                });                
            }
            return result;
        }
    }

    var graph = new Graph();
    graph.addVertex("A");
    graph.addVertex("B");
    graph.addVertex("C");
    graph.addVertex("D");
    graph.addVertex("E");
    graph.addVertex("F");
    graph.addEdge("A", "B");
    graph.addEdge("A", "C");
    graph.addEdge("B", "D");
    graph.addEdge("C", "E");
    graph.addEdge("D", "E");
    graph.addEdge("D", "F");
    graph.addEdge("E", "F");
}

//          A
//        /  \
//       /    \
//      B      C
//      |      |
//      |      |
//      D ---- E
//      \     /
//       \   /
//         F

//Output: ["A", "B", "C", "D", "E", "F"]