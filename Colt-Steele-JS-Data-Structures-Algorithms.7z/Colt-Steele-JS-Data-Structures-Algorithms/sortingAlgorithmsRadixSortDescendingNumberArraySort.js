function radixSort(numList) {
    let numOfDigitsInMaxNum = mostDigits(numList);
    for (let i = 0; i < numOfDigitsInMaxNum; i++) {
        let bucket = Array.from({length: 10}, () => []);
        for (let j = 0; j < numList.length; j++) {
            let digit = getDigit(numList[j], i);
            bucket[10 - 1 - digit].push(numList[j]);
        }
//         numList = Array.prototype.concat.apply([], bucket);
        numList = [].concat(...bucket);
    }
    return numList;
}

function getDigit(num, value) {
    num = (Math.abs(num)).toString();
    return value < num.length ? parseInt(num.charAt(num.length - 1 - value),10) : 0;
}

function mostDigits(numArr) {
    let max = 0;
    numArr.forEach(num => {
        const maxDigit = digitCount(num);
        if (maxDigit > max) {
            max = maxDigit;
        }
    });
    return max;
}

function digitCount(num) {
    return Math.abs(num).toString().length ? Math.abs(num).toString().length : 0;
}


