{
    class PriorityQueue {
        constructor() {
            this.values = [];
        }
        enqueue(val, priority) {
            this.values.push({val, priority});
            this.sort();
            return this.values;
        }
        dequeue() {
            return this.values.shift();
        }
        sort() {
            //Sorting - O(N * log(N))
            this.values.sort((a,b) => a.priority - b.priority);
        }
    }
    var queue = new PriorityQueue();
    queue.enqueue("B", 3);
    queue.enqueue("C", 5);
    queue.enqueue("D", 2);
    queue.enqueue("Q", 20);
}