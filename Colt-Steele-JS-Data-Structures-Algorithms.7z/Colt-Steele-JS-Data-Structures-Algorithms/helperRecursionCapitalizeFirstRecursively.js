function capitalizeFirst (str) {
    if (str.length === 0) return null;
    let capArr = [];
    function helper (helperArr) {
        if (helperArr.length === 0) {
            return "";
        }
        capArr.push(helperArr[0][0].toUpperCase() + helperArr[0].slice(1));
        helper(helperArr.slice(1)); 
    }
    helper(str);
    return capArr;
}