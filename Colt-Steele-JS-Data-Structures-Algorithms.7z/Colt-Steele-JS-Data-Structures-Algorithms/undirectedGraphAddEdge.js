{
    class Graph {
        constructor() {
            this.adjacancyList = {};
        }

        addVertex(vertex) {
            if(!this.adjacancyList[vertex]) this.adjacancyList[vertex] = [];
            return this.adjacancyList;
        }

        addEdge(vertex1, vertex2) {
            //For directed graph, push once. Pushing twice gives 2 directional flow
            if(!this.adjacancyList[vertex1]) this.addVertex(vertex1);
            this.adjacancyList[vertex1].push(vertex2);
            if(!this.adjacancyList[vertex2]) this.addVertex(vertex2);
            this.adjacancyList[vertex2].push(vertex1);
            return this.adjacancyList;
        }
    }

    var graph = new Graph();
    graph.addVertex("Mango");
    graph.addVertex("Guava");
    graph.addVertex("Apple");
}