function maxSubarraySum(arr, n){
    //[1,4,2,10,23, 3,1,0,20],4
    if (arr.length < n) return null;
    let maxSum = 0;
    for (let i = 0; i < n; i++) {
        maxSum += arr[i];
    }
    let tempSum = maxSum;
    for (let i = n; i < arr.length; i++) {
        tempSum = tempSum - arr[i-n] + arr[i];
        maxSum = Math.max(tempSum, maxSum);
    }
    return maxSum;
}