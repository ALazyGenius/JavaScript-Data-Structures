function binarySearch (sortedArr, n) {
    let min = 0;
    let max = sortedArr.length - 1;
    while (min <= max && sortedArr.length > 0) {
        let mid = Math.floor((max + min)/2.0);
        if (n === sortedArr[mid]) {
            return mid;
        } else if (n > sortedArr[mid]) {
            min = mid + 1;
        } else {
            max = mid - 1;
        }
    }
    return -1;
}