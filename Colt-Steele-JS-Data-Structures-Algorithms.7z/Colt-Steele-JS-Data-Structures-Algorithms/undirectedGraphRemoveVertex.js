{
    class Graph {
        constructor() {
            this.adjacancyList = {};
        }

        addVertex(vertex) {
            if(!this.adjacancyList[vertex]) this.adjacancyList[vertex] = [];
            return this.adjacancyList;
        }

        addEdge(vertex1, vertex2) {
            //For directed graph, push once. Pushing twice gives 2 directional flow
            if(!this.adjacancyList[vertex1]) this.addVertex(vertex1);
            this.adjacancyList[vertex1].push(vertex2);
            if(!this.adjacancyList[vertex2]) this.addVertex(vertex2);
            this.adjacancyList[vertex2].push(vertex1);
            return this.adjacancyList;
        }

        removeEdge(vertex1, vertex2) {
            this.adjacancyList[vertex1] = 
                this.adjacancyList[vertex1].includes(vertex2) ? 
                    this.adjacancyList[vertex1].filter(x => x !== vertex2) : 
                        this.adjacancyList[vertex1];
            this.adjacancyList[vertex2] = 
                this.adjacancyList[vertex2].includes(vertex1) ? 
                    this.adjacancyList[vertex2].filter(x => x !== vertex1) : 
                        this.adjacancyList[vertex2];
            return this.adjacancyList;
        }

        removeVertex(vertex) {
            if (this.adjacancyList[vertex] && this.adjacancyList !== {}) {
                this.adjacancyList[vertex].forEach(element => {
                    this.removeEdge(vertex, element);
                })
                delete this.adjacancyList[vertex];
            }
            return this.adjacancyList;
        }
    }

    var graph = new Graph();
    graph.addVertex("Mango");
    graph.addVertex("Guava");
    graph.addVertex("Apple");
    graph.addEdge("Banana", "Plum");
    graph.addEdge("Mango", "Guava");
    graph.addEdge("Mango", "Apple");
}