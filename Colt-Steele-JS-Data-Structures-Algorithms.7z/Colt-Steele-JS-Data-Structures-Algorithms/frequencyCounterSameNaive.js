function same(arr1, arr2) {
    if(arr1.length !== arr2.length) {
        return false;
    }
    for (const val of arr1) {
        if (arr2.indexOf(val ** 2) !== -1) {
            arr2.splice(arr2.indexOf(val ** 2), 1);
        } else {
            return false;
        }
         
    }
    return true;
}