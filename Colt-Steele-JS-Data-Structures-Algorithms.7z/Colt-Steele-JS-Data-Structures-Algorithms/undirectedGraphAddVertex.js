{
    class Graph {
        constructor() {
            this.adjacancyList = {};
        }

        addVertex(vertex) {
            if(!this.adjacancyList[vertex]) this.adjacancyList[vertex] = [];
            return this.adjacancyList;
        }
    }

    var graph = new Graph();
    graph.addVertex("Mango");
    graph.addVertex("Guava");
    graph.addVertex("Apple");
}