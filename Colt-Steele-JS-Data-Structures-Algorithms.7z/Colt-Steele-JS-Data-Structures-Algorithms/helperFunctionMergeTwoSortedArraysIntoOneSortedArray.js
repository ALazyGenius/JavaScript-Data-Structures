function merge (sortedArr1, sortedArr2) {
    //[1,10,50],[2,14,99,100]
    let mergedArr = [];
    let i = 0;
    let j = 0;
    while (i <= sortedArr1.length-1 && j <= sortedArr2.length - 1) {
        if (sortedArr1[i] < sortedArr2[j]) {
            mergedArr.push(sortedArr1[i]);
            i++;
        } else if (sortedArr1[i] > sortedArr2[j]) {
            mergedArr.push(sortedArr2[j]);
            j++;
        } else {
            mergedArr.push(sortedArr1[i]);
            mergedArr.push(sortedArr2[j]);
            i++;
            j++;
        }
    }
    if (i === sortedArr1.length) {
        while (j  < sortedArr2.length) {
            mergedArr.push(sortedArr2[j]);
            j++;
        }
    } else if (j === sortedArr2.length) {
        while (i  < sortedArr1.length) {
            mergedArr.push(sortedArr1[i]);
            i++;
        } 
    }
    return mergedArr;
}