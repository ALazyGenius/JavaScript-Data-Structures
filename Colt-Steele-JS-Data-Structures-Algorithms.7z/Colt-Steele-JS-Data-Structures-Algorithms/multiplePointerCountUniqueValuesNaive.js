function countUniqueValues(sortedArr) {
    //[1,2,3,4,4,4,5,6,7,7]
    var count = 0;
    if (sortedArr.length === 0) {
        return count;
    } else if (sortedArr.length === 1) {
        return count++;
    } else {
        for (let i = 0; i < sortedArr.length; i++) {
            for (let j = i+1; j < sortedArr.length; j++) {
                if (sortedArr[i] === sortedArr[j]) {
                    j++;
                    continue;
                } else {
                    count++;
                    i++;
                }
            }
        }
        return count;
    }
}