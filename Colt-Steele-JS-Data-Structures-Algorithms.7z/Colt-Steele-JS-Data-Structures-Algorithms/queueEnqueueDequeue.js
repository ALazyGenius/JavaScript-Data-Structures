{
    class Node {
        constructor(val) {
            this.value = val;
            this.next = null;
        }
    }

    class Queue {
        constructor() {
            this.first = null;
            this.last = null;
            this.size = 0;
        }

        enqueue(val) {
            var newNode = new Node(val);
            if (!this.first) {
                this.first = newNode;
                this.last = this.first;
            } else {
               this.last.next = newNode;
               this.last = newNode;
            }
            return ++this.size;
        }

        dequeue() {
            if (!this.first) {
                return null;
            }
            var temp = this.first;
            if (this.first === this.last) {
                this.last = null;
            } 
            this.first = this.first.next;
            this.size--;
            return temp.value;
        }
    }

    var queue = new Queue();
    queue.enqueue("Akash");
    queue.enqueue("Mishra");
    queue.enqueue("is");
    queue.enqueue("a");
    queue.enqueue("good");
    queue.enqueue("boy");
}