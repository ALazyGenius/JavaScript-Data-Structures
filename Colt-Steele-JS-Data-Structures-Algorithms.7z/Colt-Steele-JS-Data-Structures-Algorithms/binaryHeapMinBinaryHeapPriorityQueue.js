{
    class Node {
        constructor(val, priority) {
            this.val = val;
            this.priority = priority;
        }
    }
    class PriorityQueue {
        constructor() {
            this.values = [];
        }
        insert(value, priority) {
            let node = new Node(value, priority)
            if (!value) return undefined;
            this.values.push(node);
            this.bubbleUp();
        }
        bubbleUp() {
            let index = this.values.length - 1;
            const element = this.values[index];
            while(index > 0) {
                let parentIndex = Math.floor((index - 1)/2);
                let parent = this.values[parentIndex];
                if (element.priority >= parent.priority) break;
                this.swap(this.values, index, parentIndex);
                index = parentIndex;
            }
            return this.values;
        }
        extractMax() {
            const max = this.values[0];
            this.swap(this.values, 0, this.values.length - 1);
            if (this.values.length > 0) {
                this.values.pop();
                this.sinkDown();
            }
            return max;
        }
        sinkDown() {
            let index = 0;
            const length = this.values.length;
            const element = this.values[index];
            while(true) {
                let leftChildIndex = 2 * index + 1;
                let rightChildIndex = 2 * index + 2;
                let swap = null;
                let valAtChildLeft, valAtChildRight;
                if (leftChildIndex < length) {
                    valAtChildLeft = this.values[leftChildIndex];
                    if (valAtChildLeft.priority < element.priority) {
                        swap = leftChildIndex;
                    }
                }
                if (rightChildIndex < length) {
                    valAtChildRight = this.values[rightChildIndex];
                    if ((!swap && valAtChildRight.priority < element.priority) ||
                        (swap && valAtChildRight.priority < valAtChildLeft.priority)) {
                        swap = rightChildIndex;
                    }
                }
                if (!swap) {
                    break;
                }
                this.swap(this.values, index, swap);
                index = swap;
            }
        }
        swap(arr, el1, el2) {
            var temp = arr[el1];
            arr[el1] = arr[el2];
            arr[el2] = temp;
            return arr;
        }
    }

    var heap = new PriorityQueue();
    heap.insert(41, 1);
    heap.insert(39, 2);
    heap.insert(33, 3);
    heap.insert(18, 4);
    heap.insert(27, 5);
    heap.insert(12, 6);
    heap.insert(55, 7);
    heap.insert(75, 8);
    heap.insert(60, 9);
    heap.insert(199, 10);
}


//                              199
//                  75                      41
//          55              60          12             33
//      18      39      27