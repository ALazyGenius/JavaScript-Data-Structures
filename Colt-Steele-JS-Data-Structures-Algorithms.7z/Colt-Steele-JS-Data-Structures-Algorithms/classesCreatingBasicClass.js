{
    class Student2 {
        constructor(firstName, lastName, year){
            this.firstName = firstName;
            this.lastName = lastName;
            this.grade = year;
        }
    }

    let firstStudent = new Student2("Akash", "Mishra",10);
}