{
    class Node {
        constructor(val) {
            this.value = val;
            this.next = null;
            this.prev = null
        }
    }

    class DoublyLinkedList {
        constructor() {
            this.head = null;
            this.tail = null;
            this.length = 0;
        }

        push(val) {
            var newNode = new Node(val);
            if (!this.head) {
                this.head = newNode;
                this.tail = this.head;
            } else {
                this.tail.next = newNode;
                newNode.prev = this.tail;
                this.tail = newNode;
            }
            this.length += 1;
            return this;
        }

        get(index) {
            if (index < 0 || index >= this.length) {
                return null;
            }
            var current;
            if (index <= Math.floor(this.length/2)) {
                let count = 0;
                current = this.head;
                while (count < index) {
                    current = current.next;
                    count++;
                }
            } else {
                let count = this.length - 1;
                current = this.tail;
                while (count > index) {
                    current = current.prev;
                    count--;
                }
            }
            return current;
        }

        pop() {
            if (!this.head) return null;
            let last = this.tail;
            if (this.length === 1) {
                this.head = null;
                this.tail = this.head;
            } else {
                this.tail = last.prev;
                this.tail.next = null;
                last.prev = null;
            }            
            this.length--;
            console.log(this);
            return last;
        }

        shift() {
            if (!this.head) {
                return null;
            }
            var oldHead = this.head;
            if (this.length === 1) {
                this.head = null;
                this.tail = null;
            } else {
                this.head = oldHead.next;
                this.head.prev = null;
                oldHead.next = null;
            }
            this.length--;
            console.log(this);
            return oldHead;
        }

        remove(index) {
            if (index < 0 || index > this.length) {
                return null;
            } else if (index === 0) {
                return this.shift();
            } else if (index === this.length) {
                return this.pop()
            } else {
                let prevNode = this.get(index - 1);
                let currentNode = this.get(index);
                let afterNode = currentNode.next;
                prevNode.next = afterNode;
                afterNode.prev = prevNode;
                currentNode.next = null;
                currentNode.prev = null;
                this.length--;
                return currentNode;
            }
        }
    }

    var list = new DoublyLinkedList();
    list.push("Akash");
    list.push("Mishra");
    list.push("is");
    list.push("a");
    list.push("good");
    list.push("boy");
}