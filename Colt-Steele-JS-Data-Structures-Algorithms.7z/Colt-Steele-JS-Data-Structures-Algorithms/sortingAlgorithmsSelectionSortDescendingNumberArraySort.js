function selectionSort (arr) {
    for (let i = 0; i < arr.length; i++) {
        let max = i;
        for (let j = i+1; j < arr.length; j++) {
            if (arr[j] > arr[max]) {
                max = j;
            }
        }
        if (i != max) {
            arr = swap(arr, i, max)   
        }
    }
    return arr;
}

function swap (arr,x,y) {
    let temp = arr[x];
    arr[x] = arr[y];
    arr[y] = temp;
    return arr;
}