{
    class Node {
        constructor(value) {
            this.value = value;
            this.left = null;
            this.right = null;
        }
    }
     class BinarySearchTree {
        constructor() {
            this.root = null;
        }
        insert(value) {
            let newNode = new Node(value);
            if (!this.root) {
                this.root = newNode;
                return this;
            } else {
                var current = this.root;
                while (true) {
                    if (value === current.value) {
                        return undefined;
                    }
                    if (newNode.value < current.value) {
                        if (!current.left) {
                            current.left = newNode;
                            return this;
                        } else {
                            current = current.left;
                        }
                    } else if (newNode.value > current.value) {
                        if (!current.right) {
                            current.right = newNode;
                            return this;
                        } else {
                            current = current.right;
                        }
                    }
                }
            }
        }
        BFSBreadthFirst() {
            var data = [];
            var queue = [];
            var current = this.root;
            queue.push(current);
            while(queue.length) {
                current = queue.shift();
                data.push(current.value);
                if (current.left) queue.push(current.left);
                if (current.right) queue.push(current.right);
            }
            return data;
        }
     }

     var tree = new BinarySearchTree();
     tree.insert(10);
     tree.insert(5);
     tree.insert(13);
     tree.insert(11);
     tree.insert(2);
     tree.insert(16);
     tree.insert(7);
}

//              10
//      5               13
//  2       7       11      16   