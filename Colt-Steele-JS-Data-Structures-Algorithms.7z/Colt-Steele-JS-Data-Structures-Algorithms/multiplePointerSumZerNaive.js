function sumZero(sortedArr) {
    for (let i = 0;  i < sortedArr.length; i++) {
        for (let j = i; j < sortedArr.length; j++) {
            if (sortedArr[i] + sortedArr[j] === 0) {
                return [sortedArr[i], sortedArr[j]];
            }
        }
    } 
}