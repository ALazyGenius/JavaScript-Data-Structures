{
    class Node {
    constructor(val) {
        this.value = val;
        this.next = null;
        }
    }

    class SinglyLinkedList {
        constructor() {
            this.head = null;
            this.tail = null;
            this.length = 0;
        }

        push(val) {
            var newNode = new Node(val);
            if (!this.head) {
                this.head = newNode;
                this.tail = this.head;
            } else {
                this.tail.next = newNode;
                this.tail = newNode;
            }
            this.length += 1;
            return this;
        }

        get(index) {
            if (index < 0 || index >= this.length) {
                return null;
            }
            if (index === 0) {
                return this.head;
            } else {
                var count = 0;
                var nodeAtIndex = null;
                var current = this.head;
                while (count !== index) {
                    current = current.next;
                    nodeAtIndex = current;
                    count++;
                }
                return nodeAtIndex;
            }

        }
    }

    var list = new SinglyLinkedList();
    list.push("Hi");
    list.push("I");
    list.push("am");
    list.push("Akash");
    list.push("Mishra");
}