function sortStrLength (strArr) {
    return strArr.sort((a,b) => b.length - a.length);
}