function mostDigits(numArr) {
    let max = 0;
    numArr.forEach(num => {
        const maxDigit = digitCount(num);
        if (maxDigit > max) {
            max = maxDigit;
        }
    });
    return max;
}

function digitCount(num) {
    return Math.abs(num).toString().length ? Math.abs(num).toString().length : 0;
}


