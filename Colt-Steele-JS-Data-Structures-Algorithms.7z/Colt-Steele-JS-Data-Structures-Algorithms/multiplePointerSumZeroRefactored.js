function sumZero(sortedArr){
    let leftPointer = 0;
    let rightPointer = sortedArr.length - 1;
    while (leftPointer < rightPointer) {
        const sum = sortedArr[leftPointer] + sortedArr[rightPointer];
        if (sum === 0) {
            return [sortedArr[leftPointer], sortedArr[rightPointer]];
        } else if (sum < 0) {
            leftPointer++;
        } else {
            rightPointer--;
        }
    }
}